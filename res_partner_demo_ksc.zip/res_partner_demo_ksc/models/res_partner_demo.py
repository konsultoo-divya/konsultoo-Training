from odoo import models, fields, api
from datetime import date
from datetime import datetime

class Customers(models.Model):
    _name = 'res.partner.demo.ksc'
    _description = 'res partner Data'

    name = fields.Char(string='Name', translate=True)
    email = fields.Char(string="Email Id")
    street1 = fields.Char(string="Street1")
    street2 = fields.Char(string="street2")
    city = fields.Char(string="City")
    state = fields.Char(string="State")
    zip_code = fields.Char(string="Zip Code")
    country = fields.Char(string="Country")
    birthdate = fields.Date(string='BirthDate', default=datetime.today())
    age = fields.Integer(string="Age", compute='_compute_age')
    weight = fields.Float(string="Weight")
    description = fields.Text(string="Description")
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('transgender)', 'Transgender)')],
                              default='female', string="Gender")
    detail = fields.Html('Detail', sanitize=True, strip_style=False)
    is_spectacles = fields.Boolean(string="Is_spectacles")
    extra_detail = fields.Html(string="extra_detail")
    state = fields.Selection([
        ('draft', 'Quotation'),
        ('sent', 'Quotation Sent'),
        ('sale', 'Sales Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled'),
    ], string='Status', readonly=True, copy=False)

    # calculating age base on Birthdate using @api depends()
    @api.depends("birthdate")
    def _compute_age(self):
        for rec in self:
            today = date.today()
            if rec.birthdate:
                rec.age = today.year - rec.birthdate.year
            else:
                rec.age = 1
